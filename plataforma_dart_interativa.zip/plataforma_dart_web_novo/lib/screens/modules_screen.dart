import 'package:flutter/material.dart';

class ModulesScreen extends StatelessWidget {
  const ModulesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Lista de módulos
    final modules = [
      {
        'title': 'Introdução ao Dart',
        'description': 'Conceitos básicos e sintaxe da linguagem',
        'icon': Icons.school,
        'progress': 0.0,
      },
      {
        'title': 'Variáveis e Tipos',
        'description': 'Tipos de dados e declaração de variáveis',
        'icon': Icons.data_object,
        'progress': 0.0,
      },
      {
        'title': 'Estruturas de Controle',
        'description': 'Condicionais e loops',
        'icon': Icons.loop,
        'progress': 0.0,
      },
      {
        'title': 'Funções',
        'description': 'Declaração e uso de funções',
        'icon': Icons.functions,
        'progress': 0.0,
      },
      {
        'title': 'Coleções',
        'description': 'Listas, mapas e conjuntos',
        'icon': Icons.list_alt,
        'progress': 0.0,
      },
      {
        'title': 'Programação Orientada a Objetos',
        'description': 'Classes, objetos e herança',
        'icon': Icons.category,
        'progress': 0.0,
      },
      {
        'title': 'Async/Await',
        'description': 'Programação assíncrona',
        'icon': Icons.timelapse,
        'progress': 0.0,
      },
      {
        'title': 'Gerenciamento de Erros',
        'description': 'Try/catch e exceções',
        'icon': Icons.error_outline,
        'progress': 0.0,
      },
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Módulos de Aprendizado'),
        backgroundColor: Theme.of(context).colorScheme.primary,
        foregroundColor: Theme.of(context).colorScheme.onPrimary,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Theme.of(context).colorScheme.primary.withOpacity(0.7),
              Theme.of(context).colorScheme.secondary.withOpacity(0.5),
            ],
          ),
        ),
        child: ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: modules.length,
          itemBuilder: (context, index) {
            final module = modules[index];
            return Card(
              margin: const EdgeInsets.only(bottom: 16),
              elevation: 4,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        CircleAvatar(
                          backgroundColor: Theme.of(context).colorScheme.primary,
                          foregroundColor: Theme.of(context).colorScheme.onPrimary,
                          child: Icon(module['icon'] as IconData),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                module['title'] as String,
                                style: const TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                module['description'] as String,
                                style: TextStyle(
                                  color: Colors.grey[600],
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          width: 40,
                          height: 40,
                          child: IconButton(
                            icon: const Icon(Icons.arrow_forward),
                            onPressed: () {
                              // TODO: Navegar para a tela do módulo
                            },
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    LinearProgressIndicator(
                      value: module['progress'] as double,
                      backgroundColor: Colors.grey[300],
                      valueColor: AlwaysStoppedAnimation<Color>(
                        Theme.of(context).colorScheme.primary,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Progresso: ${((module['progress'] as double) * 100).toInt()}%',
                      style: TextStyle(
                        color: Colors.grey[600],
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
} 